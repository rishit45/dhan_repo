import time
import requests
from datetime import datetime

from dhanhq import dhanhq, DhanContext

from config_loader import load_config, get_all_instrument_configs


# ── DHAN CLOUD VARIABLES ──────────────────────────────────────────────────────
# These are substituted automatically by Dhan Cloud at runtime.
# Do NOT use os.getenv() here - it is hard-blocked on Dhan Cloud.
# Set CLIENT_ID and ACCESS_TOKEN under Settings > Global Variables (or per-strategy
# Variables tab) in the Dhan Cloud dashboard.

client_id    = "{{CLIENT_ID}}"      # substituted by Dhan Cloud at runtime
access_token = "{{ACCESS_TOKEN}}"   # substituted by Dhan Cloud at runtime

dhan_context = DhanContext(client_id, access_token)   # holds credentials for dhanhq calls
dhan         = dhanhq(dhan_context)                    # used here ONLY for read-only calls (LTP, quotes)


# ── EXECUTION HAND-OFF ENDPOINT ───────────────────────────────────────────────
# Dhan Cloud has no persistent filesystem and the scanner blocks place_order().
# Signals are POSTed to an external endpoint you control (your own server,
# or a service like Supabase/Firebase) which then places the real order.
# Set this as a Dhan Cloud Variable too, e.g. {{EXECUTION_WEBHOOK_URL}}

EXECUTION_WEBHOOK_URL = "{{EXECUTION_WEBHOOK_URL}}"   # e.g. "https://your-server.com/execute"

POLL_INTERVAL_SECS = 5   # seconds between signal checks; always sleep inside the loop on Dhan Cloud


def get_ltp(instrument_config):
    """
    Fetches live LTP for one instrument using dhanhq's get_ltp().

    Args:
        instrument_config (dict) - validated config for this instrument

    Returns:
        ltp (float) - current live traded price
    """
    instruments = [(instrument_config["exchange_segment"], instrument_config["security_id"])]
    response    = dhan.get_ltp(instruments)   # {"data": {exchange_segment: {security_id: {"last_price": ...}}}}

    exchange_segment = instrument_config["exchange_segment"]
    security_id      = instrument_config["security_id"]

    ltp = response["data"][exchange_segment][security_id]["last_price"]  # current live price, float
    return ltp


def evaluate_signal(instrument_key, instrument_config):
    """
    Your strategy logic goes here. This example fires a BUY signal once,
    at the instrument's configured entry_time, with no further conditions.
    Replace the condition with your actual indicator/strategy check.

    Returns:
        signal (dict|None) - signal payload if a trade should fire, else None
    """
    now = datetime.now().time()   # current time of day

    if now < instrument_config["entry_time"]:
        return None   # not yet time to enter

    ltp = get_ltp(instrument_config)   # current live price, used as the reference entry price

    signal = {
        "instrument_key":    instrument_key,
        "tradingsymbol":     instrument_config["tradingsymbol"],
        "security_id":       instrument_config["security_id"],
        "exchange_segment":  instrument_config["exchange_segment"],
        "transaction_type":  "BUY",                       # replace with your actual strategy direction
        "quantity":          instrument_config["qty"],
        "order_type":        instrument_config["order_type"],
        "product_type":      instrument_config["product_type"],
        "reference_price":   ltp,                          # price at signal time, for logging/reference
        "target_mode":       instrument_config["target_mode"],
        "target_value":      instrument_config["target_value"],
        "sl_mode":           instrument_config["sl_mode"],
        "sl_value":          instrument_config["sl_value"],
        "signal_time":       datetime.now().isoformat(),
    }
    return signal


def send_signal_for_execution(signal):
    """
    Hands the signal off to the external execution endpoint.
    This is the ONLY way a Dhan Cloud strategy should trigger a real order -
    never call dhan.place_order() directly inside Dhan Cloud code.

    Args:
        signal (dict) - payload from evaluate_signal()
    """
    try:
        response = requests.post(EXECUTION_WEBHOOK_URL, json=signal, timeout=5)
        print(f"[SIGNAL SENT] {signal['instrument_key']} {signal['transaction_type']} "
              f"-> webhook status {response.status_code}")
    except Exception as e:
        print(f"[SIGNAL SEND FAILED] {signal['instrument_key']}: {e}")


def run_signal_generator():
    """
    Main loop for Dhan Cloud. Continuously checks every configured instrument
    for a signal and posts it to the execution webhook when one fires.
    Never calls dhan.place_order() - this process only generates and sends signals.
    """
    raw_config      = load_config()                          # full parsed config.json
    all_instruments = get_all_instrument_configs(raw_config)  # {instrument_key: validated config dict}

    fired = set()  # instrument_keys that have already fired a signal today, avoids re-firing every poll

    print("Signal generator started (Dhan Cloud mode - read-only, no order placement)")

    while True:
        for instrument_key, instrument_config in all_instruments.items():
            if instrument_key in fired:
                continue   # already signaled today, skip until process restarts

            signal = evaluate_signal(instrument_key, instrument_config)

            if signal is not None:
                send_signal_for_execution(signal)
                fired.add(instrument_key)

        time.sleep(POLL_INTERVAL_SECS)   # required: Dhan Cloud will terminate loops with no sleep


if __name__ == "__main__":
    run_signal_generator()
