"""
RUN THIS LOCALLY OR ON YOUR OWN SERVER - NEVER ON DHAN CLOUD.

This file starts the webhook server (order_executor.py) that receives signals
from the Dhan Cloud signal generator and places the real orders. This is the
only process in the whole system allowed to call dhan.place_order().

Before running:
  export DHAN_CLIENT_ID="your_client_id"
  export DHAN_ACCESS_TOKEN="your_access_token"
  pip install dhanhq flask requests

Then expose this server's /execute endpoint to the internet (e.g. via ngrok,
a cloud VM, or your own domain) and point Dhan Cloud's EXECUTION_WEBHOOK_URL
variable at it.

Once an entry order is placed, also start monitoring it for target/SL/square-off
using position_monitor.monitor_position() - see README.md for the full flow.
"""

from order_executor import app

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
