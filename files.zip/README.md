# Trading System v2 — dhanhq edition, Dhan Cloud safe

This is a rewrite of the original Tradehull-based modular trading system,
using raw `dhanhq` + `DhanContext` instead of `Dhan_Tradehull`, and split so
that order placement never happens inside Dhan Cloud's restricted container.

## Why the split exists

Dhan Cloud's code scanner blocks calls that execute financial transactions
(e.g. `dhan.place_order()`) inside deployed strategy code. So this project
is split into two halves that run in two different places:

| Half | Runs on | Allowed to call `place_order`? |
|---|---|---|
| **Signal generation** | Dhan Cloud | No |
| **Order execution** | Your own server / local machine | Yes |

The two halves talk to each other over a plain HTTP webhook.

## Files

```
config.json              menu — instrument settings (qty, target, SL, times, security IDs)
config_loader.py          reads + validates config.json
target_sl_calculator.py   pure math: turns points/absolute into price levels (no SDK dependency)

signal_generator.py       DHAN CLOUD — reads live price, decides BUY/SELL, POSTs signal out
main_cloud.py             entry point you deploy to Dhan Cloud

order_executor.py         LOCAL — receives signal via webhook, calls dhan.place_order()
position_monitor.py       LOCAL — polls live price, exits at target/SL/square-off
main_local.py             entry point you run on your own machine/server
```

## Setup — Dhan Cloud side

1. Create a new strategy in the Dhan Cloud dashboard.
2. Upload: `main_cloud.py`, `signal_generator.py`, `config_loader.py`, `config.json`
3. In the strategy's **Dependencies** tab, add:
   ```
   dhanhq==2.0.1
   requests
   ```
4. In **Variables** (Settings > Global Variables, or this strategy's Variables tab), set:
   ```
   CLIENT_ID             = your Dhan client ID
   ACCESS_TOKEN          = your Dhan access token
   EXECUTION_WEBHOOK_URL = https://your-server.com/execute
   ```
5. Deploy. The scanner will pass since `signal_generator.py` never calls `place_order`.

## Setup — local execution side

1. On your own machine or server:
   ```bash
   pip install dhanhq flask requests
   export DHAN_CLIENT_ID="your_client_id"
   export DHAN_ACCESS_TOKEN="your_access_token"
   python main_local.py
   ```
2. Expose port 5000 to the internet (e.g. `ngrok http 5000` for testing, or a
   real domain + reverse proxy for production) so Dhan Cloud can reach `/execute`.
3. Point the Dhan Cloud `EXECUTION_WEBHOOK_URL` variable at that public URL.

## What happens end to end

1. `signal_generator.py` (on Dhan Cloud) checks each instrument in `config.json`.
2. When entry conditions are met, it builds a signal dict and POSTs it to your webhook.
3. `order_executor.py` (on your server) receives it, calls `dhan.place_order()` for real.
4. You then call `position_monitor.monitor_position()` with that same signal to
   watch target/SL/square-off and auto-exit (run this as a background task per
   open position on the local side, not on Dhan Cloud).

## Changing instrument settings

Edit only `config.json` — qty, target, SL, order type, entry/square-off time.
No code changes needed on either the Cloud or local side.

## Updating `security_id` values

Futures contracts roll over monthly. Update each instrument's `security_id`
in `config.json` from Dhan's instrument master CSV:
https://images.dhan.co/api-data/api-scrip-master.csv
