"""
DEPLOY THIS FILE TO DHAN CLOUD.

This is the ONLY file that should run inside Dhan Cloud's strategy container.
It imports signal_generator, which never calls dhan.place_order() - it only
reads live prices and POSTs signals to your external execution webhook.

Before deploying:
  1. Set Variables in the Dhan Cloud dashboard (Settings > Global Variables,
     or this strategy's Variables tab):
       CLIENT_ID              = your Dhan client ID
       ACCESS_TOKEN            = your Dhan access token
       EXECUTION_WEBHOOK_URL   = https://your-server.com/execute

  2. Declare dependencies in the Dependencies tab:
       dhanhq==2.0.1
       requests

  3. Upload config.json, config_loader.py, signal_generator.py alongside this file.
"""

from signal_generator import run_signal_generator

if __name__ == "__main__":
    run_signal_generator()
