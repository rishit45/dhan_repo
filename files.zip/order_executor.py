import os
from flask import Flask, request, jsonify

from dhanhq import dhanhq, DhanContext


# ── CREDENTIALS ───────────────────────────────────────────────────────────────
# This file runs LOCALLY / on your own server, NOT on Dhan Cloud.
# os.environ is fine here - there is no Dhan Cloud scanner restriction outside
# the Cloud container.

CLIENT_ID    = os.environ.get("DHAN_CLIENT_ID")
ACCESS_TOKEN = os.environ.get("DHAN_ACCESS_TOKEN")

if not CLIENT_ID or not ACCESS_TOKEN:
    raise EnvironmentError(
        "Missing credentials. Set DHAN_CLIENT_ID and DHAN_ACCESS_TOKEN "
        "as environment variables before running."
    )

dhan_context = DhanContext(CLIENT_ID, ACCESS_TOKEN)   # holds credentials for dhanhq calls
dhan         = dhanhq(dhan_context)                    # the only client allowed to place real orders


def place_entry_order(signal):
    """
    Places the entry order for one signal received from the signal generator.
    This is THE function that actually executes a financial transaction -
    it must never run inside Dhan Cloud code, only here.

    Args:
        signal (dict) - payload sent by signal_generator.send_signal_for_execution()

    Returns:
        order_id (str|None) - the order ID returned by Dhan, or None on failure
    """
    order_type = signal["order_type"]                         # "MARKET" or "LIMIT"
    price      = signal.get("reference_price", 0) if order_type == "LIMIT" else 0

    try:
        response = dhan.place_order(
            security_id      = signal["security_id"],
            exchange_segment = signal["exchange_segment"],
            transaction_type = signal["transaction_type"],     # "BUY" or "SELL"
            quantity          = signal["quantity"],
            order_type        = order_type,
            product_type      = signal["product_type"],
            price             = price,
        )
        order_id = response.get("orderId")   # Dhan's order ID, or None if rejected
        print(f"[ORDER PLACED] {signal['tradingsymbol']} {signal['transaction_type']} "
              f"qty={signal['quantity']} -> order_id={order_id}")
        return order_id

    except Exception as e:
        print(f"[ORDER FAILED] {signal['tradingsymbol']} {signal['transaction_type']}: {e}")
        return None


def place_exit_order(signal):
    """
    Places the opposite-side order to close a position opened from a signal.

    Args:
        signal (dict) - the ORIGINAL entry signal (same dict used in place_entry_order)

    Returns:
        order_id (str|None) - the order ID returned by Dhan, or None on failure
    """
    exit_transaction_type = "SELL" if signal["transaction_type"] == "BUY" else "BUY"  # opposite side closes it

    try:
        response = dhan.place_order(
            security_id      = signal["security_id"],
            exchange_segment = signal["exchange_segment"],
            transaction_type = exit_transaction_type,
            quantity          = signal["quantity"],
            order_type        = "MARKET",          # exits always go at market, for certainty of fill
            product_type      = signal["product_type"],
            price             = 0,
        )
        order_id = response.get("orderId")
        print(f"[EXIT PLACED] {signal['tradingsymbol']} {exit_transaction_type} "
              f"qty={signal['quantity']} -> order_id={order_id}")
        return order_id

    except Exception as e:
        print(f"[EXIT FAILED] {signal['tradingsymbol']} {exit_transaction_type}: {e}")
        return None


# ── WEBHOOK RECEIVER ──────────────────────────────────────────────────────────
# Receives signals POSTed by signal_generator.py (running on Dhan Cloud) and
# immediately places the real order. Run this with: python order_executor.py
# Point Dhan Cloud's EXECUTION_WEBHOOK_URL variable at wherever this is hosted,
# e.g. https://your-server.com/execute

app = Flask(__name__)


@app.route("/execute", methods=["POST"])
def execute_signal():
    signal   = request.get_json()        # the signal dict sent by signal_generator.py
    order_id = place_entry_order(signal)

    if order_id is None:
        return jsonify({"status": "failed"}), 500

    return jsonify({"status": "placed", "order_id": order_id}), 200


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
