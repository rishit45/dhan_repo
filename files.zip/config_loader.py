import json
import os
from datetime import datetime


CONFIG_PATH = os.path.join(os.path.dirname(__file__), "config.json")  # path to the menu file

VALID_ORDER_TYPES = {"MARKET", "LIMIT"}      # allowed values for order_type
VALID_MODES       = {"points", "absolute"}   # allowed values for target_mode / sl_mode


def load_config(path=CONFIG_PATH):
    """
    Reads config.json from disk and returns the raw dict.
    """
    with open(path, "r") as f:
        raw_config = json.load(f)   # full parsed JSON as a Python dict
    return raw_config


def list_instruments(raw_config):
    """
    Returns the list of instrument keys defined in the config,
    e.g. ["NIFTY_FUT", "CRUDEOIL_FUT", "NATURALGAS_FUT"]
    """
    instrument_keys = list(raw_config["instruments"].keys())  # all instrument names in the menu
    return instrument_keys


def get_instrument_config(raw_config, instrument_key):
    """
    Returns one instrument's settings, merged with defaults, validated,
    and with entry_time / square_off_time converted to time objects.

    Returns:
        dict with keys:
            tradingsymbol     (str)   - e.g. "NIFTY JUN FUT", for logging only
            security_id       (str)   - Dhan security ID, required by dhanhq calls
            exchange_segment  (str)   - e.g. "NSE_FNO", "MCX_COMM" (dhanhq enum string)
            qty               (int)   - order quantity
            order_type        (str)   - "MARKET" or "LIMIT"
            product_type      (str)   - e.g. "INTRADAY", "MARGIN", "CNC"
            target_mode       (str)   - "points" or "absolute"
            target_value      (float) - points to add, or absolute exit price
            sl_mode           (str)   - "points" or "absolute"
            sl_value          (float) - points to subtract, or absolute exit price
            entry_time        (time)  - time of day to enter
            square_off_time   (time)  - time of day to force-exit
    """
    if instrument_key not in raw_config["instruments"]:
        raise KeyError(
            f"'{instrument_key}' not found in config.json. "
            f"Available: {list_instruments(raw_config)}"
        )

    instrument_settings = raw_config["instruments"][instrument_key]  # this instrument's raw settings dict
    defaults            = raw_config.get("defaults", {})              # fallback values dict

    order_type   = instrument_settings.get("order_type",   defaults.get("order_type",   "MARKET"))
    product_type = instrument_settings.get("product_type", defaults.get("product_type", "INTRADAY"))
    target_mode  = instrument_settings.get("target_mode",  defaults.get("target_mode",  "points"))
    sl_mode      = instrument_settings.get("sl_mode",       defaults.get("sl_mode",      "points"))

    if order_type not in VALID_ORDER_TYPES:
        raise ValueError(f"Invalid order_type '{order_type}' for {instrument_key}")
    if target_mode not in VALID_MODES:
        raise ValueError(f"Invalid target_mode '{target_mode}' for {instrument_key}")
    if sl_mode not in VALID_MODES:
        raise ValueError(f"Invalid sl_mode '{sl_mode}' for {instrument_key}")

    entry_time_str      = instrument_settings.get("entry_time", "09:20")       # "HH:MM" string from config
    square_off_time_str = instrument_settings.get("square_off_time", "15:15")  # "HH:MM" string from config

    entry_time      = datetime.strptime(entry_time_str, "%H:%M").time()       # time object, entry trigger
    square_off_time = datetime.strptime(square_off_time_str, "%H:%M").time()  # time object, forced exit

    return {
        "tradingsymbol":    instrument_settings["tradingsymbol"],
        "security_id":      instrument_settings["security_id"],
        "exchange_segment": instrument_settings["exchange_segment"],
        "qty":              instrument_settings["qty"],
        "order_type":       order_type,
        "product_type":     product_type,
        "target_mode":      target_mode,
        "target_value":     instrument_settings["target_value"],
        "sl_mode":          sl_mode,
        "sl_value":         instrument_settings["sl_value"],
        "entry_time":       entry_time,
        "square_off_time":  square_off_time,
    }


def get_all_instrument_configs(raw_config):
    """
    Returns a dict of every instrument's validated config, keyed by instrument_key.
    """
    all_configs = {}  # instrument_key -> validated config dict
    for instrument_key in list_instruments(raw_config):
        all_configs[instrument_key] = get_instrument_config(raw_config, instrument_key)
    return all_configs


if __name__ == "__main__":
    raw_config = load_config()
    for key in list_instruments(raw_config):
        cfg = get_instrument_config(raw_config, key)
        print(key, "->", cfg)
